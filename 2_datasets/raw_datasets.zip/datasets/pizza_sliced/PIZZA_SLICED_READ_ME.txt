espacenet search 20/03/2015

1. Advanced Search. Titles and Abstracts (pizza) = 3,238
2. Publication Date 1990:2014 = 2826
3. Break down search to 500 or less per set
2000:2002
2003:2005
2006:2008
2009:2012
2013:2014

Results = approximate espacenet results sets reduced on load more records for export. 


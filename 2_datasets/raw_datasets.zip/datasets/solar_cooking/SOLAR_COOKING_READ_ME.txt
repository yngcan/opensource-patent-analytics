The solar cooking dataset is taken from the WIPO patent landscape report on solar cooking and can be accessed here http://www.wipo.int/patentscope/en/programs/patent_landscapes/reports/solar_cooking.html

Note that this file contains multiple worksheets. In R use sheet numbers rather than titles when loading. 
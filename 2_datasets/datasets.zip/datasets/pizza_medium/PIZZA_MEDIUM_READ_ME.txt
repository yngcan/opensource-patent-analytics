Pizza

Dataset from WIPO Patent Scope search for pizza on the 5th March 2015.

Simple search of full text. on "pizza" produces 24,614 results. The pizza dataset contains the first 10,000 results of the 24,614. 
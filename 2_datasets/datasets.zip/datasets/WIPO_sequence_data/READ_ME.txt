A sample of DNA sequence listings  in Patent Cooperation Applications for the year 2000. The dataset comes from WIPO Patent Scope.

1. https://patentscope.wipo.int/search/en/sequences.jsf 
2. Via ftp choose guest and then select a year or multiple.
3. Note that one year is provided because of data size. 

Downloaded 21/04/2015
Paul Oldham 


This folder contains patent datasets for use with the WIPO Open Source Patent Analytics project (http://poldham.github.io/opensource-patent-analytics/). The datasets may be freely used for educational and training purposes. Please credit the sources in the Read Me file when using the datasets. 

Each folder contains datasets in .csv and/or Excel file. The datasets are different sizes and vary in their internal formats. They are intended to reflect the variety of different forms patent data may be received in along with a variety of different data fields. 

The raw_datasets.zip file contains the archive of the original files. 

A YouTube project channel is now available here: 

https://www.youtube.com/channel/UCwFhEASbKdm6WYoax73XsOw?spfreload=10

We will be demonstrating how to access, clean up and visualize the data from these datasets using a variety of tools. 

The key starting point is the pizza_small dataset. 

More datasets will be added in due course. 

Paul Oldham likes pizza and is the creator of the pizza training sets. 

For questions please contact the project email: opensourcepatentanalytics@gmail.com